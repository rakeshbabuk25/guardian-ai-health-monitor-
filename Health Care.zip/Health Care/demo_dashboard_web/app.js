// UI Elements
const hrEl = document.getElementById("hr-value");
const hrvEl = document.getElementById("hrv-value");
const voiceEl = document.getElementById("voice-value");
const blinkEl = document.getElementById("blink-value");
const fatigueEl = document.getElementById("fatigue-value");
const motionEl = document.getElementById("motion-value");
const logEl = document.getElementById("event-log");

const barMap = {
  normal: document.getElementById("bar-normal"),
  fatigued: document.getElementById("bar-fatigued"),
  stressed: document.getElementById("bar-stressed"),
  critical: document.getElementById("bar-critical"),
};

let time = 0;
let simFatigue = 0.3;
let simStress = 0.2;
let simMotion = 0.1;

// TensorFlow.js model
let mlModel = null;
let modelLoaded = false;
let modelLoading = false;

// Chart instances
let charts = {
  heartRate: null,
  hrv: null,
  voiceStress: null,
  blinkRate: null,
  fatigue: null,
  alertState: null
};

// Chart data storage (last 50 data points)
const MAX_DATA_POINTS = 50;
let chartData = {
  heartRate: { labels: [], values: [] },
  hrv: { labels: [], values: [] },
  voiceStress: { labels: [], values: [] },
  blinkRate: { labels: [], values: [] },
  fatigue: { labels: [], values: [] },
  alertState: { labels: [], values: [] }
};

function clamp(val, min, max) {
  return Math.min(max, Math.max(min, val));
}

function log(message) {
  if (!logEl) return;
  const item = document.createElement("li");
  const timestamp = new Date().toLocaleTimeString();
  item.textContent = `[${timestamp}] ${message}`;
  logEl.prepend(item);
  while (logEl.children.length > 50) {
    logEl.removeChild(logEl.lastChild);
  }
}

// Simulated sensor data generator
function simulateSensors() {
  time += 0.2;
  const circadian = Math.sin(time * 0.05) * 5;
  const heartRate = 72 + circadian + Math.sin(time * 0.8) * 3 + Math.random() * 2;
  const hrv = 45 + Math.sin(time * 0.7) * 8 - simStress * 10;

  if (Math.random() > 0.92) simStress = clamp(simStress + 0.3, 0, 1);
  else simStress *= 0.98;

  if (Math.random() > 0.95) simFatigue = clamp(simFatigue + 0.2, 0, 1);
  else simFatigue *= 0.995;

  simMotion = clamp(simStress * 0.5 + Math.random() * 0.2, 0, 1);

  const voice = clamp(0.15 + simStress + Math.random() * 0.05, 0, 1);
  const blinkRate = 18 - simFatigue * 8 + Math.random() * 2;
  const fatigueScore = clamp(simFatigue + Math.random() * 0.02, 0, 1);

  return {
    heartRate,
    heartRateVariability: hrv,
    voiceStressScore: voice,
    blinkRate,
    facialFatigueScore: fatigueScore,
    imuMotionScore: simMotion,
  };
}

// Load ML model - try backend first, then TensorFlow.js, then heuristic
async function loadMLModel() {
  if (modelLoaded || modelLoading) return;
  modelLoading = true;
  
  // First, check if ML backend is available (preferred - uses real .tflite model)
  try {
    const response = await fetch('http://localhost:5000/health', { method: 'GET', mode: 'cors' });
    if (response.ok) {
      const healthData = await response.json();
      if (healthData.models_loaded.includes('health_monitor')) {
        modelLoaded = true;
        modelLoading = false;
        log("✓ ML Backend server available - using real TinyML models");
        return true;
      }
    }
  } catch (error) {
    // Backend not available, continue to TensorFlow.js
  }
  
  // Fallback to TensorFlow.js (only if backend is not available)
  // Note: TensorFlow.js models may not exist - this is expected if using backend
  try {
    const modelPath = '../ml/training/artifacts/tfjs_model/model.json';
    mlModel = await tf.loadLayersModel(modelPath);
    modelLoaded = true;
    modelLoading = false;
    log("✓ TensorFlow.js model loaded successfully - using real ML inference");
    return true;
  } catch (error) {
    // TensorFlow.js model not available - this is OK if using backend
    // Only log as warning if backend was also unavailable
    if (error.message && error.message.includes('404')) {
      // Suppress 404 errors - TensorFlow.js models are optional when using backend
      console.log("TensorFlow.js model not found (this is OK if ML backend is running)");
    } else {
      console.warn("Could not load TensorFlow.js model, using heuristic fallback:", error);
    }
    modelLoading = false;
    return false;
  }
}

// TinyML inference - uses real model if available, otherwise heuristic
async function runTinyMLInference(sensorData) {
  // Normalize features (same as firmware FeaturePipeline)
  const hr = clamp((sensorData.heartRate - 40) / 120, 0, 1);
  const hrv = clamp((sensorData.heartRateVariability - 10) / 110, 0, 1);
  const voice = sensorData.voiceStressScore;
  const blink = clamp((sensorData.blinkRate - 5) / 35, 0, 1);
  const fatigue = sensorData.facialFatigueScore;
  const motion = sensorData.imuMotionScore;
  
  // Build 16-feature vector (matching firmware)
  const features = [
    hr, hrv, voice, blink, fatigue, motion,
    1.0, 1.0, 1.0, // Placeholder features
    fatigue, fatigue, fatigue, fatigue, fatigue, fatigue, fatigue // Padding
  ].slice(0, 16);

  // Try ML backend first (preferred - uses real .tflite model)
  if (modelLoaded) {
    try {
      const response = await fetch('http://localhost:5000/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        mode: 'cors',
        body: JSON.stringify({
          project: 'health_monitor',
          features: features
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        const classes = ["Normal", "Fatigued", "Stressed", "Critical"];
        return {
          probabilities: data.probabilities,
          classification: classes[data.winning_index],
          maxIdx: data.winning_index,
          usingML: true
        };
      }
    } catch (error) {
      // Backend unavailable, try TensorFlow.js
    }
  }

  // Fallback to TensorFlow.js model
  if (modelLoaded && mlModel) {
    try {
      const input = tf.tensor2d([features], [1, 16]);
      const prediction = mlModel.predict(input);
      const probs = await prediction.data();
      input.dispose();
      prediction.dispose();
      
      const probabilities = Array.from(probs);
      const maxIdx = probabilities.indexOf(Math.max(...probabilities));
      const classes = ["Normal", "Fatigued", "Stressed", "Critical"];
      return { probabilities, classification: classes[maxIdx], maxIdx, usingML: true };
    } catch (error) {
      console.error("Model inference error:", error);
      // Fall through to heuristic
    }
  }

  // Heuristic fallback (same as before)
  const logits = [
    1.2 - fatigue * 0.8 - voice * 0.6 - motion * 0.5,
    fatigue * 1.4 + (1 - blink) * 0.6,
    voice * 1.5 + (1 - hrv) * 0.8,
    motion * 1.2 + hr * 0.8 + (1 - hrv) * 0.6,
  ];

  const exp = logits.map((l) => Math.exp(l));
  const sum = exp.reduce((a, b) => a + b, 0);
  const probabilities = exp.map((v) => v / sum);
  const maxIdx = probabilities.indexOf(Math.max(...probabilities));
  const classes = ["Normal", "Fatigued", "Stressed", "Critical"];
  
  return { probabilities, classification: classes[maxIdx], maxIdx, usingML: false };
}

function updateBars(probabilities) {
  const states = ["normal", "fatigued", "stressed", "critical"];
  const colors = ["var(--normal)", "var(--fatigue)", "var(--stress)", "var(--critical)"];
  let winner = 0;
  probabilities.forEach((p, idx) => {
    const width = `${(p * 100).toFixed(1)}%`;
    const indicator = barMap[states[idx]].querySelector(".fill");
    if (indicator) {
      indicator.style.width = width;
      indicator.style.background = colors[idx];
    }
    if (p > probabilities[winner]) winner = idx;
  });

  return ["Normal", "Fatigued", "Stressed", "Critical"][winner];
}

// Initialize Chart.js charts
function initializeCharts() {
  const chartConfig = {
    type: 'line',
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#fff' }
        },
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#fff', maxTicksLimit: 10 }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  };

  // Heart Rate Chart
  charts.heartRate = new Chart(document.getElementById('chart-heart-rate'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'Heart Rate',
        data: [],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.1)',
        tension: 0.4
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 40, max: 120 }
      }
    }
  });

  // HRV Chart
  charts.hrv = new Chart(document.getElementById('chart-hrv'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'HRV',
        data: [],
        borderColor: 'rgb(54, 162, 235)',
        backgroundColor: 'rgba(54, 162, 235, 0.1)',
        tension: 0.4
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 20, max: 80 }
      }
    }
  });

  // Voice Stress Chart
  charts.voiceStress = new Chart(document.getElementById('chart-voice-stress'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'Voice Stress',
        data: [],
        borderColor: 'rgb(255, 165, 0)',
        backgroundColor: 'rgba(255, 165, 0, 0.1)',
        tension: 0.4
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 0, max: 1.0 }
      }
    }
  });

  // Blink Rate Chart
  charts.blinkRate = new Chart(document.getElementById('chart-blink-rate'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'Blink Rate',
        data: [],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.1)',
        tension: 0.4
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 0, max: 40 }
      }
    }
  });

  // Fatigue Chart
  charts.fatigue = new Chart(document.getElementById('chart-fatigue'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'Fatigue',
        data: [],
        borderColor: 'rgb(153, 102, 255)',
        backgroundColor: 'rgba(153, 102, 255, 0.1)',
        tension: 0.4
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 0, max: 1.0 }
      }
    }
  });

  // Alert State Chart
  charts.alertState = new Chart(document.getElementById('chart-alert-state'), {
    ...chartConfig,
    data: {
      labels: [],
      datasets: [{
        label: 'Alert State',
        data: [],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.1)',
        tension: 0.4,
        stepped: 'after'
      }]
    },
    options: {
      ...chartConfig.options,
      scales: {
        ...chartConfig.options.scales,
        y: { ...chartConfig.options.scales.y, min: 0, max: 3, ticks: { stepSize: 1 } }
      }
    }
  });
}

// Update charts with new data
function updateCharts(sensorData, alertState) {
  const now = new Date().toLocaleTimeString();
  
  function addDataPoint(chartName, value) {
    const chart = charts[chartName];
    if (!chart) return;
    
    chartData[chartName].labels.push(now);
    chartData[chartName].values.push(value);
    
    if (chartData[chartName].labels.length > MAX_DATA_POINTS) {
      chartData[chartName].labels.shift();
      chartData[chartName].values.shift();
    }
    
    chart.data.labels = chartData[chartName].labels;
    chart.data.datasets[0].data = chartData[chartName].values;
    chart.update('none');
  }

  addDataPoint('heartRate', sensorData.heartRate);
  addDataPoint('hrv', sensorData.heartRateVariability);
  addDataPoint('voiceStress', sensorData.voiceStressScore);
  addDataPoint('blinkRate', sensorData.blinkRate);
  addDataPoint('fatigue', sensorData.facialFatigueScore);
  addDataPoint('alertState', alertState);
}

async function processSensorReading() {
  const sensorData = simulateSensors();
  const result = await runTinyMLInference(sensorData);
  
  const state = updateBars(result.probabilities);
  
  // Update UI
  hrEl.textContent = `${sensorData.heartRate.toFixed(1)} bpm`;
  hrvEl.textContent = `${sensorData.heartRateVariability.toFixed(1)} ms`;
  voiceEl.textContent = sensorData.voiceStressScore.toFixed(2);
  motionEl.textContent = sensorData.imuMotionScore.toFixed(2);
  fatigueEl.textContent = sensorData.facialFatigueScore.toFixed(2);
  blinkEl.textContent = `${sensorData.blinkRate.toFixed(1)}`;
  
  // Update charts
  updateCharts(sensorData, result.maxIdx);
  
  log(`State: ${state} | probs ${result.probabilities.map((p) => p.toFixed(2)).join(", ")}`);
}

// Initialize on page load
(async () => {
  await loadMLModel();
  initializeCharts();
  log("System initialized. Monitoring health metrics...");
  
  setInterval(processSensorReading, 500);
})();
