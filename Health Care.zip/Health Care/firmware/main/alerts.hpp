#pragma once

#include "ai_processor.hpp"
#include "sensors.hpp"

enum class AlertLevel {
    kNormal = 0,
    kFatigued = 1,
    kStressed = 2,
    kCritical = 3,
};

class AlertManager {
public:
    esp_err_t init();
    void update(const SensorReadings &readings,
                const InferenceResult &result);

private:
    void drive_led(AlertLevel level);
    void drive_buzzer(AlertLevel level);
    AlertLevel last_alert_ = AlertLevel::kNormal;
};



