#pragma once

#include <array>
#include <cstdint>

#include "feature_pipeline.hpp"

struct InferenceResult {
    float probabilities[4];
    int winning_index;
};

class AiProcessor {
public:
    esp_err_t init();
    esp_err_t infer(const FeatureVector &features, InferenceResult &result);

private:
    bool initialized_ = false;
};



