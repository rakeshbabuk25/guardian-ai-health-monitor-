#pragma once

#include <array>
#include <cstdint>

#include "esp_err.h"

struct SensorReadings {
    float heart_rate_bpm;
    float heart_rate_variability;
    float voice_stress_score;
    float blink_rate;
    float facial_fatigue_score;
    float imu_motion_score;
    bool ppg_valid;
    bool voice_valid;
    bool face_valid;
};

class SensorHub {
public:
    esp_err_t init();
    esp_err_t sample(SensorReadings &out_readings);

private:
    esp_err_t init_ppg();
    esp_err_t init_microphone();
    esp_err_t init_camera();
    esp_err_t init_imu();

    esp_err_t read_ppg(float &hr, float &hrv, bool &valid);
    esp_err_t read_voice(float &stress, bool &valid);
    esp_err_t read_face(float &blink_rate, float &fatigue, bool &valid);
    esp_err_t read_imu(float &motion_score);
};



