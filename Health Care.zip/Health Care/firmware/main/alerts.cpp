#include "alerts.hpp"

#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_log.h"

namespace {
constexpr char kTag[] = "Alerts";
constexpr gpio_num_t kLedRed = GPIO_NUM_3;
constexpr gpio_num_t kLedGreen = GPIO_NUM_46;
constexpr gpio_num_t kBuzzer = GPIO_NUM_2;
}  // namespace

esp_err_t AlertManager::init() {
    gpio_config_t io_conf{};
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pin_bit_mask = (1ULL << kLedRed) | (1ULL << kLedGreen) |
                           (1ULL << kBuzzer);
    ESP_RETURN_ON_ERROR(gpio_config(&io_conf), kTag, "gpio config");
    return ESP_OK;
}

void AlertManager::update(const SensorReadings &,
                          const InferenceResult &result) {
    AlertLevel level = static_cast<AlertLevel>(result.winning_index);
    if (level == last_alert_) {
        return;
    }
    last_alert_ = level;
    drive_led(level);
    drive_buzzer(level);
}

void AlertManager::drive_led(AlertLevel level) {
    gpio_set_level(kLedRed, level == AlertLevel::kCritical);
    gpio_set_level(kLedGreen, level == AlertLevel::kNormal);
}

void AlertManager::drive_buzzer(AlertLevel level) {
    const bool active = level == AlertLevel::kCritical ||
                        level == AlertLevel::kStressed;
    gpio_set_level(kBuzzer, active ? 1 : 0);
}



