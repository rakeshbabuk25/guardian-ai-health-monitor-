#include "feature_pipeline.hpp"

#include <algorithm>
#include <cmath>

void FeaturePipeline::build(const SensorReadings &readings,
                            FeatureVector &out_features) {
    out_features.fill(0.0f);
    size_t idx = 0;
    out_features[idx++] = normalize(readings.heart_rate_bpm, 40.0f, 160.0f);
    out_features[idx++] = normalize(readings.heart_rate_variability, 10.0f, 120.0f);
    out_features[idx++] = normalize(readings.voice_stress_score, 0.0f, 1.0f);
    out_features[idx++] = normalize(readings.blink_rate, 5.0f, 40.0f);
    out_features[idx++] = normalize(readings.facial_fatigue_score, 0.0f, 1.0f);
    out_features[idx++] = normalize(readings.imu_motion_score, 0.0f, 1.0f);
    out_features[idx++] = readings.ppg_valid ? 1.0f : 0.0f;
    out_features[idx++] = readings.voice_valid ? 1.0f : 0.0f;
    out_features[idx++] = readings.face_valid ? 1.0f : 0.0f;
    // Reserve space for rolling statistics (simple EMA placeholders).
    static float hr_ema = 0.0f;
    static float stress_ema = 0.0f;
    hr_ema = 0.9f * hr_ema + 0.1f * readings.heart_rate_bpm;
    stress_ema = 0.8f * stress_ema + 0.2f * readings.voice_stress_score;
    out_features[idx++] = normalize(hr_ema, 40.0f, 160.0f);
    out_features[idx++] = normalize(stress_ema, 0.0f, 1.0f);
    // Pad remaining slots with repeated fatigue signal to keep size static.
    while (idx < out_features.size()) {
        out_features[idx++] = readings.facial_fatigue_score;
    }
}

float FeaturePipeline::normalize(float value, float min, float max) const {
    const float clipped = std::clamp(value, min, max);
    return (clipped - min) / (max - min + 1e-3f);
}



