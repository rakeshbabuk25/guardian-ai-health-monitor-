"""
Client-facing desktop demo that reuses the trained TinyML model to
simulate the ESP32-S3 health monitor in real time.

It loads the quantized TFLite model, generates synthetic sensor readings
matching the firmware feature vector, and visualizes alert probabilities.
"""

from __future__ import annotations

import itertools
import pathlib
import time
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

MODEL_PATH = pathlib.Path(__file__).parent / "artifacts" / "guardian_model.tflite"
OUTPUT_LABELS = ["Normal", "Fatigued", "Stressed", "Critical"]


@dataclass
class Scenario:
    name: str
    heart_rate: float
    hrv: float
    voice: float
    blink: float
    fatigue: float
    motion: float


SCENARIOS = [
    Scenario("Resting", 72, 48, 0.15, 18, 0.2, 0.1),
    Scenario("Fatigued", 80, 40, 0.25, 10, 0.75, 0.2),
    Scenario("Stressed call", 96, 22, 0.65, 16, 0.45, 0.3),
    Scenario("Critical overload", 135, 18, 0.75, 8, 0.85, 0.9),
]


def build_feature_vector(scenario: Scenario) -> np.ndarray:
    """Mimic firmware FeaturePipeline output."""
    features = np.zeros(16, dtype=np.float32)
    features[0] = np.clip((scenario.heart_rate - 40.0) / 120.0, 0.0, 1.0)
    features[1] = np.clip((scenario.hrv - 10.0) / 110.0, 0.0, 1.0)
    features[2] = np.clip(scenario.voice, 0.0, 1.0)
    features[3] = np.clip((scenario.blink - 5.0) / 35.0, 0.0, 1.0)
    features[4] = scenario.fatigue
    features[5] = scenario.motion
    features[6] = 1.0  # ppg valid
    features[7] = 1.0  # voice valid
    features[8] = 1.0  # face valid
    # Fill remaining slots with fatigue proxy (same logic as firmware padding)
    features[9:] = scenario.fatigue
    return features


class TinyInterpreter:
    def __init__(self, model_path: pathlib.Path):
        if not model_path.exists():
            raise FileNotFoundError(
                f"Model not found at {model_path}. Run train_health_model.py first."
            )
        self._interpreter = tf.lite.Interpreter(model_path=str(model_path))
        self._interpreter.allocate_tensors()
        self._input = self._interpreter.get_input_details()[0]
        self._output = self._interpreter.get_output_details()[0]

    def infer(self, features: np.ndarray) -> np.ndarray:
        self._interpreter.set_tensor(self._input["index"], features[None, :])
        self._interpreter.invoke()
        return self._interpreter.get_tensor(self._output["index"])[0]


def main() -> None:
    interpreter = TinyInterpreter(MODEL_PATH)

    plt.style.use("seaborn-v0_8")
    fig, ax = plt.subplots(figsize=(8, 4))
    bars = ax.bar(OUTPUT_LABELS, [0] * len(OUTPUT_LABELS), color="#4e79a7")
    ax.set_ylim(0, 1)
    ax.set_ylabel("Probability")
    title = ax.set_title("Initializing model…")
    prob_text = ax.text(
        0.02,
        0.95,
        "",
        transform=ax.transAxes,
        verticalalignment="top",
        fontsize=10,
        bbox=dict(boxstyle="round", facecolor="white", alpha=0.7),
    )
    plt.tight_layout()
    plt.ion()
    plt.show()

    scenario_cycle = itertools.cycle(SCENARIOS)
    for scenario in scenario_cycle:
        title.set_text(f"Scenario: {scenario.name}")
        for _ in range(20):
            noisy = Scenario(
                scenario.name,
                heart_rate=np.random.normal(scenario.heart_rate, 2.5),
                hrv=np.random.normal(scenario.hrv, 2.0),
                voice=np.clip(np.random.normal(scenario.voice, 0.05), 0, 1),
                blink=np.random.normal(scenario.blink, 1.0),
                fatigue=np.clip(np.random.normal(scenario.fatigue, 0.03), 0, 1),
                motion=np.clip(np.random.normal(scenario.motion, 0.05), 0, 1),
            )
            features = build_feature_vector(noisy)
            probs = interpreter.infer(features)
            winning_idx = int(np.argmax(probs))
            for idx, bar in enumerate(bars):
                bar.set_height(float(probs[idx]))
                bar.set_color("#59a14f" if idx == winning_idx else "#4e79a7")
            prob_text.set_text(
                "\n".join(
                    f"{label}: {prob:.2%}"
                    for label, prob in zip(OUTPUT_LABELS, probs)
                )
            )
            fig.canvas.flush_events()
            time.sleep(0.25)


if __name__ == "__main__":
    main()



