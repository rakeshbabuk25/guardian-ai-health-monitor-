"""
Tiny synthetic training pipeline for the ESP32-S3 Guardian monitor.

This script fabricates physiologic/behavioral feature vectors matching
the firmware's FeaturePipeline (16 floats) and trains a small neural net.
Replace `generate_dataset` with real labeled data ingestion when available.
"""

from __future__ import annotations

import argparse
import pathlib
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import tensorflow as tf

NUM_FEATURES = 16
NUM_CLASSES = 4


@dataclass
class Dataset:
    x: np.ndarray
    y: np.ndarray


def generate_dataset(
    samples: int = 4000,
    seed: int | None = None,
) -> Tuple[Dataset, Dataset]:
    rng = np.random.default_rng(seed)
    # Base signals
    heart_rate = rng.normal(75, 10, samples)
    hrv = rng.normal(40, 10, samples)
    voice = rng.beta(2, 5, samples)
    blink = rng.normal(18, 4, samples)
    fatigue = rng.uniform(0, 1, samples)
    motion = rng.uniform(0, 1, samples)

    # State logic
    labels = np.zeros(samples, dtype=np.int32)
    labels[(fatigue > 0.6) | (blink < 12)] = 1  # fatigued
    labels[(voice > 0.5) | (hrv < 25)] = 2     # stressed
    labels[(heart_rate > 120) | (motion > 0.8)] = 3  # critical

    features = np.stack(
        [
            heart_rate,
            hrv,
            voice,
            blink,
            fatigue,
            motion,
            np.ones(samples),
            np.ones(samples),
            np.ones(samples),
        ],
        axis=1,
    )

    # Pad to 16 dims by repeating fatigue/motion patterns as firmware does.
    pad = np.tile(fatigue, (7, 1)).T
    features = np.concatenate([features, pad], axis=1)[:, :NUM_FEATURES]

    # Min-max normalize roughly matching FeaturePipeline expectations.
    features[:, 0] = np.clip((features[:, 0] - 40) / 120, 0, 1)
    features[:, 1] = np.clip((features[:, 1] - 10) / 110, 0, 1)
    features[:, 2] = np.clip(features[:, 2], 0, 1)
    features[:, 3] = np.clip((features[:, 3] - 5) / 35, 0, 1)

    permutation = rng.permutation(samples)
    train_idx = permutation[: int(samples * 0.8)]
    val_idx = permutation[int(samples * 0.8) :]

    x_train = features[train_idx].astype(np.float32)
    y_train = labels[train_idx]
    x_val = features[val_idx].astype(np.float32)
    y_val = labels[val_idx]

    return Dataset(x_train, y_train), Dataset(x_val, y_val)


def build_model() -> tf.keras.Model:
    inputs = tf.keras.Input(shape=(NUM_FEATURES,), name="features")
    x = tf.keras.layers.Dense(32, activation="relu")(inputs)
    x = tf.keras.layers.Dense(32, activation="relu")(x)
    x = tf.keras.layers.Dense(16, activation="relu")(x)
    outputs = tf.keras.layers.Dense(NUM_CLASSES, activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def train(output_dir: pathlib.Path, epochs: int, batch_size: int) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    train_ds, val_ds = generate_dataset()
    model = build_model()
    model.summary()
    model.fit(
        train_ds.x,
        train_ds.y,
        validation_data=(val_ds.x, val_ds.y),
        epochs=epochs,
        batch_size=batch_size,
        verbose=2,
    )

    keras_path = output_dir / "guardian_model.keras"
    model.save(keras_path)

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()
    tflite_path = output_dir / "guardian_model.tflite"
    tflite_path.write_bytes(tflite_model)

    # Emit C array for firmware inclusion.
    c_array_path = output_dir / "ai_model_data.cc"
    with c_array_path.open("w", encoding="utf-8") as f:
        f.write("// Auto-generated TinyML weights\n")
        f.write('#include "ai_model_data.h"\n\n')
        f.write("const unsigned char g_health_model_data[] = {\n")
        for i, byte in enumerate(tflite_model):
            if i % 12 == 0:
                f.write("    ")
            f.write(f"0x{byte:02x}, ")
            if i % 12 == 11:
                f.write("\n")
        f.write("\n};\n")
        f.write("const int g_health_model_data_len = sizeof(g_health_model_data);\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Guardian TinyML trainer")
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=pathlib.Path("artifacts"),
        help="Directory to store exported models",
    )
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=64)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    train(args.output, args.epochs, args.batch_size)


if __name__ == "__main__":
    main()


