"""
Laptop-webcam driven demo for the Guardian AI monitor.

Uses MediaPipe Face Mesh to estimate blink frequency and eye-aspect ratio
as live proxies for fatigue, then feeds those features into the TinyML
model already trained for the ESP32-S3 firmware.
"""

from __future__ import annotations

import collections
import pathlib
import time
from dataclasses import dataclass
from typing import Deque, Tuple

import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf

MODEL_PATH = pathlib.Path(__file__).parent / "artifacts" / "guardian_model.tflite"
OUTPUT_LABELS = ["Normal", "Fatigued", "Stressed", "Critical"]

# Indices of eye landmarks in MediaPipe FaceMesh
LEFT_EYE = [33, 159, 133, 145, 153, 154]
RIGHT_EYE = [362, 386, 263, 374, 380, 385]


@dataclass
class FeatureState:
    heart_rate: float = 78.0
    hrv: float = 42.0
    voice: float = 0.3
    blink_rate: float = 18.0
    fatigue: float = 0.3
    motion: float = 0.2


class TinyInterpreter:
    def __init__(self, model_path: pathlib.Path):
        if not model_path.exists():
            raise FileNotFoundError(
                f"Model not found at {model_path}. Run train_health_model.py first."
            )
        self._interpreter = tf.lite.Interpreter(model_path=str(model_path))
        self._interpreter.allocate_tensors()
        self._input = self._interpreter.get_input_details()[0]
        self._output = self._interpreter.get_output_details()[0]

    def infer(self, features: np.ndarray) -> np.ndarray:
        self._interpreter.set_tensor(self._input["index"], features[None, :])
        self._interpreter.invoke()
        return self._interpreter.get_tensor(self._output["index"])[0]


def eye_aspect_ratio(landmarks: list[mp.framework.formats.landmark_pb2.NormalizedLandmark]) -> float:
    # EAR formula using selected landmark pairs
    def dist(a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return np.linalg.norm(np.array(a) - np.array(b))

    p2 = (landmarks[1].x, landmarks[1].y)
    p6 = (landmarks[5].x, landmarks[5].y)
    p3 = (landmarks[2].x, landmarks[2].y)
    p5 = (landmarks[4].x, landmarks[4].y)
    p1 = (landmarks[0].x, landmarks[0].y)
    p4 = (landmarks[3].x, landmarks[3].y)
    vertical = dist(p2, p6) + dist(p3, p5)
    horizontal = dist(p1, p4)
    if horizontal == 0:
        return 0.0
    return vertical / (2.0 * horizontal)


def build_feature_vector(state: FeatureState) -> np.ndarray:
    feats = np.zeros(16, dtype=np.float32)
    feats[0] = np.clip((state.heart_rate - 40.0) / 120.0, 0.0, 1.0)
    feats[1] = np.clip((state.hrv - 10.0) / 110.0, 0.0, 1.0)
    feats[2] = np.clip(state.voice, 0.0, 1.0)
    feats[3] = np.clip((state.blink_rate - 5.0) / 35.0, 0.0, 1.0)
    feats[4] = np.clip(state.fatigue, 0.0, 1.0)
    feats[5] = np.clip(state.motion, 0.0, 1.0)
    feats[6:9] = 1.0
    feats[9:] = feats[4]
    return feats


def main() -> None:
    interpreter = TinyInterpreter(MODEL_PATH)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("Webcam not accessible.")

    mp_face_mesh = mp.solutions.face_mesh.FaceMesh(
        static_image_mode=False,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    state = FeatureState()
    blink_history: Deque[float] = collections.deque(maxlen=200)
    blink_counter = 0
    ear_threshold = 0.25
    last_blink_time = time.time()

    while True:
        success, frame = cap.read()
        if not success:
            break
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = mp_face_mesh.process(frame_rgb)
        height, width = frame.shape[:2]

        if results.multi_face_landmarks:
            landmarks = results.multi_face_landmarks[0].landmark
            left = [landmarks[i] for i in LEFT_EYE]
            right = [landmarks[i] for i in RIGHT_EYE]
            ear_left = eye_aspect_ratio(left)
            ear_right = eye_aspect_ratio(right)
            ear = (ear_left + ear_right) / 2.0
            cv2.putText(frame, f"EAR {ear:.3f}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            state.fatigue = np.clip(1.0 - ear * 2.3, 0.0, 1.0)
            if ear < ear_threshold:
                blink_counter += 1
            else:
                if blink_counter >= 2:
                    current_time = time.time()
                    blink_history.append(current_time)
                    last_blink_time = current_time
                blink_counter = 0

            if blink_history:
                current_time = time.time()
                window = current_time - blink_history[0]
                if window > 0.3:
                    rate = len(blink_history) * 60.0 / window
                    state.blink_rate = np.clip(rate, 5.0, 40.0)
            else:
                elapsed = time.time() - last_blink_time
                decay_rate = max(5.0, 60.0 / max(1.0, elapsed * 2.0))
                state.blink_rate = np.clip(decay_rate, 5.0, 30.0)
        else:
            # No face detected -> degrade confidence
            state.fatigue = min(1.0, state.fatigue + 0.01)

        # Idle motion / heart rate remain synthetic but could be mapped to other sensors.
        features = build_feature_vector(state)
        probs = interpreter.infer(features)
        state_idx = int(np.argmax(probs))

        cv2.rectangle(frame, (10, height - 140), (250, height - 40), (0, 0, 0), -1)
        for i, label in enumerate(OUTPUT_LABELS):
            color = (0, 255, 0) if i == state_idx else (255, 255, 255)
            cv2.putText(frame, f"{label}: {probs[i]:.2f}",
                        (20, height - 110 + i * 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        cv2.imshow("Guardian Webcam Demo", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == 27 or key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

